# Atlas AI Trading v0.2 — free historical-data upgrade

This archive contains the original Streamlit application under `artifacts/atlas-ai-trading/`, with historical-price support added. The default remains **Demo (offline)**. Switch to **Historical (free, internet required)** in the sidebar to request up to two years of adjusted daily OHLCV history for the included stocks and crypto assets via Yahoo Finance/yfinance. Unavailable symbols are excluded, not silently replaced with fake data. Each chart shows the latest bar date. A manual refresh clears the one-hour cache.

## Replit installation

1. Back up the existing Replit project. Upload the extracted `artifacts/atlas-ai-trading/live_data.py`, `app.py`, and `test_live_data.py` to the corresponding project folder, replacing `app.py` only after backup. Keep all other original files.
2. Add `yfinance>=0.2.54` to the project's root `requirements.txt` (included here).
3. Run the existing Streamlit workflow. If needed: `streamlit run artifacts/atlas-ai-trading/app.py --server.address 0.0.0.0 --server.port 8501`.
4. To test: `cd artifacts/atlas-ai-trading && python -m unittest discover -v`.
5. Choose Historical mode in the sidebar. If a provider request fails, use Demo mode. Historical mode requires outbound network access.

## Limitations and safety

- No paid API keys, no broker connection, no live execution, and no real-money trading.
- Yahoo Finance data may be delayed, incomplete, rate-limited, or unavailable; yfinance is an unofficial integration. Check Yahoo's data terms and obtain commercial market-data licenses before distributing or selling historical quotes.
- Paper orders use the most recent historical close, not a tradable quote. A single shared local SQLite paper account is **not suitable for public multi-user deployment**.
- The ML model's probabilities are uncalibrated and its holdout accuracy is not a guarantee of future performance. No profit is implied.
- The archive intentionally omits `.env`, databases, dependency folders, caches, and any project secrets. It is a minimal source-code patch rather than a full Replit workspace snapshot.
